var TOTAL = 45;
var respostas = [];

var elIdade = document.getElementById("idade");
var elSexo = document.getElementById("sexo");
var elOpiniao = document.getElementById("opiniao");
var elErro = document.getElementById("erro");
var elResultados = document.getElementById("resultados");

function atualizarProgresso() {
  var feitas = respostas.length;
  var atual = feitas < TOTAL ? feitas + 1 : TOTAL;
  document.getElementById("contador").textContent =
    feitas < TOTAL ? "Pessoa " + atual + " de " + TOTAL : "Pesquisa concluída (" + TOTAL + " de " + TOTAL + ")";
  var pct = (feitas / TOTAL) * 100;
  document.getElementById("percentual").textContent = Math.round(pct) + "%";
  document.getElementById("barra").style.width = pct + "%";

  var concluida = feitas >= TOTAL;
  document.getElementById("btnRegistrar").disabled = concluida;
  elIdade.disabled = concluida;
  elSexo.disabled = concluida;
  elOpiniao.disabled = concluida;
}

function registrar() {
  var idade = parseInt(elIdade.value);
  var sexo = elSexo.value;
  var opiniao = parseInt(elOpiniao.value);

  if (isNaN(idade) || idade <= 0 || idade > 120) {
    elErro.textContent = "Digite uma idade válida (1 a 120).";
    return;
  }
  if (sexo === "") {
    elErro.textContent = "Selecione o sexo.";
    return;
  }
  if (isNaN(opiniao)) {
    elErro.textContent = "Selecione a opinião sobre o filme.";
    return;
  }

  elErro.textContent = "";
  respostas.push({ idade: idade, sexo: sexo, opiniao: opiniao });

  elIdade.value = "";
  elSexo.value = "";
  elOpiniao.value = "";
  elIdade.focus();

  atualizarProgresso();

  if (respostas.length === TOTAL) {
    mostrarResultados();
  }
}

function mostrarResultados() {
  if (respostas.length === 0) {
    elErro.textContent = "Registre ao menos uma resposta para ver os resultados.";
    return;
  }

  var somaIdades = 0;
  var maisVelha = respostas[0].idade;
  var maisNova = respostas[0].idade;
  var qtdPessimo = 0;
  var qtdOtimoBom = 0;
  var qtdF = 0;
  var qtdM = 0;
  var qtdO = 0;

  for (var i = 0; i < respostas.length; i++) {
    var r = respostas[i];

    somaIdades += r.idade;
    if (r.idade > maisVelha) { maisVelha = r.idade; }
    if (r.idade < maisNova) { maisNova = r.idade; }

    if (r.opiniao === 1) { qtdPessimo++; }
    if (r.opiniao === 3 || r.opiniao === 4) { qtdOtimoBom++; }

    if (r.sexo === "F") { qtdF++; }
    else if (r.sexo === "M") { qtdM++; }
    else { qtdO++; }
  }

  var total = respostas.length;
  var media = somaIdades / total;
  var pctOtimoBom = (qtdOtimoBom / total) * 100;

  document.getElementById("rMedia").textContent = media.toFixed(2) + " anos";
  document.getElementById("rVelha").textContent = maisVelha + " anos";
  document.getElementById("rNova").textContent = maisNova + " anos";
  document.getElementById("rPessimo").textContent = qtdPessimo;
  document.getElementById("rOtimoBom").textContent = pctOtimoBom.toFixed(2) + "%";
  document.getElementById("rF").textContent = qtdF;
  document.getElementById("rM").textContent = qtdM;
  document.getElementById("rO").textContent = qtdO;

  document.getElementById("nota").textContent = total < TOTAL
    ? "Resultados parciais: " + total + " de " + TOTAL + " respostas."
    : "Resultado final com as " + TOTAL + " respostas.";

  elResultados.hidden = false;
  elResultados.scrollIntoView({ behavior: "smooth" });
}

function preencherTeste() {
  var sexos = ["F", "M", "O"];
  while (respostas.length < TOTAL) {
    respostas.push({
      idade: 12 + Math.floor(Math.random() * 60),
      sexo: sexos[Math.floor(Math.random() * 3)],
      opiniao: 1 + Math.floor(Math.random() * 4)
    });
  }
  atualizarProgresso();
  mostrarResultados();
}

function reiniciar() {
  respostas = [];
  elErro.textContent = "";
  elResultados.hidden = true;
  atualizarProgresso();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

document.getElementById("btnRegistrar").addEventListener("click", registrar);
document.getElementById("btnParcial").addEventListener("click", mostrarResultados);
document.getElementById("btnTeste").addEventListener("click", preencherTeste);
document.getElementById("btnReiniciar").addEventListener("click", reiniciar);

atualizarProgresso();
